MoreRoutes is a quality of life mod that allows handlers to have up to 15 routes, instead of the normal 5.

**Drag to scroll down** to see routes that go off the page.

**Installation**
1. Install [MelonLoader](https://melonwiki.xyz/#/?id=automated-installation)
2. Extract the zip file
3. Place the **MoreRoutes.dll** into the **Mods** folder (at your game install location)
4. Launch the game and enjoy!