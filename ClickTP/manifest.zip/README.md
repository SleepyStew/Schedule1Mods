ClickTP is a simple Quality of Life mod that allows you to traverse the map faster and easier.

**To teleport:** look at an object or in any direction and press either (Left) **Alt**, or **Mouse 4** (Front, Side Mouse Button - For those who have it)

**Installation**
1. Install [MelonLoader](https://melonwiki.xyz/#/?id=automated-installation)
2. Extract the zip file
3. Place the **ClickTP.dll** into the **Mods** folder (at your game install location)
4. Launch the game and enjoy