EasyRemove is a quality of life mod that allows you to easily remove pot plants with seeds in them, shelves with items, and any other build-able item.

To activate the mod, **hold Shift** and hold right click to destroy the item as you normally would.

**Installation**
1. Install [MelonLoader](https://melonwiki.xyz/#/?id=automated-installation)
2. Extract the zip file
3. Place the **EasyRemove.dll** into the **Mods** folder (at your game install location)
4. Launch the game and enjoy